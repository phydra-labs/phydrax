
#include <fstream>
#include <iomanip>
#define main flexodeal_reference_program_main
#include "flexodeal.cc"
#undef main

class MaterialOracle : public Flexodeal::Muscle_Tissues_Three_Field<3> {
public:
  using Flexodeal::Muscle_Tissues_Three_Field<3>::Muscle_Tissues_Three_Field;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_length_stress;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_dlength_stress_dstretch;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_strain_rate_stress;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_dstrain_rate_stress_dstrain_rate;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_passive_stress;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_dpassive_stress_dstretch;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_aponeurosis_stress;
  using Flexodeal::Muscle_Tissues_Three_Field<3>::get_daponeurosis_stress_dstretch;
};

template <typename T> void matrix(const T &value) {
  std::cout << '[';
  for (unsigned int i=0; i<3; ++i) {
    if (i) std::cout << ',';
    std::cout << '[';
    for (unsigned int j=0; j<3; ++j) {
      if (j) std::cout << ',';
      std::cout << value[i][j];
    }
    std::cout << ']';
  }
  std::cout << ']';
}

int main(int argc, char **argv) {
  if (argc != 2) return 2;
  std::ifstream input(argv[1]);
  if (!input) return 3;
  std::cout << std::setprecision(17);
  unsigned int id, tissue, dynamic;
  while (input >> id >> tissue >> dynamic) {
    double p[12], pressure, dilation, activation, dt;
    dealii::Tensor<2,3> F, previous;
    dealii::Tensor<1,3> direction;
    for (auto &v : p) input >> v;
    for (unsigned int i=0; i<3; ++i)
      for (unsigned int j=0; j<3; ++j) input >> F[i][j];
    for (unsigned int i=0; i<3; ++i)
      for (unsigned int j=0; j<3; ++j) input >> previous[i][j];
    input >> pressure >> dilation >> activation >> dt;
    for (unsigned int i=0; i<3; ++i) input >> direction[i];
    if (!input || (tissue != 1 && tissue != 2)) return 4;
    MaterialOracle material(dynamic ? "dynamic" : "quasi-static", tissue,
      p[0], p[1], p[5], p[4], direction[0], direction[1], direction[2],
      p[2], p[3], p[9], p[10], p[11], p[6], p[7], p[8]);
    const auto grad_velocity = (F-previous)/dt;
    material.update_material_data(F, pressure, dilation, activation, grad_velocity, dt);
    const auto tau = material.get_tau();
    const dealii::Tensor<2,3> full_tau(tau);
    const auto first_piola = full_tau * dealii::transpose(dealii::invert(F));
    std::cout << "{\"id\":" << id << ",\"tissue_id\":" << tissue
      << ",\"dynamic\":" << (dynamic ? "true" : "false") << ",\"parameter_values\":[";
    for (unsigned int i=0; i<12; ++i) {
      if (i) std::cout << ',';
      std::cout << p[i];
    }
    std::cout << "],\"F\":"; matrix(F);
    std::cout << ",\"F_previous\":"; matrix(previous);
    std::cout << ",\"reference_grad_velocity\":"; matrix(grad_velocity);
    std::cout << ",\"reference_direction\":[" << direction[0] << ','
      << direction[1] << ',' << direction[2] << ']';
    std::cout << ",\"pressure_Pa\":" << pressure << ",\"dilation\":" << dilation
      << ",\"activation\":" << activation << ",\"dt_s\":" << dt;
    std::cout << ",\"first_piola_Pa\":"; matrix(first_piola);
    std::cout << ",\"kirchhoff_Pa\":"; matrix(tau);
    std::cout << ",\"kirchhoff_volumetric_Pa\":"; matrix(material.get_tau_vol());
    std::cout << ",\"source_unweighted_active_Pa\":"; matrix(material.get_tau_iso_muscle_active());
    std::cout << ",\"source_unweighted_passive_fiber_Pa\":"; matrix(material.get_tau_iso_muscle_passive());
    std::cout << ",\"source_unweighted_base_Pa\":"; matrix(material.get_tau_iso_muscle_basematerial());
    std::cout << ",\"volume_ratio\":" << material.get_det_F()
      << ",\"fiber_stretch\":" << material.get_stretch()
      << ",\"isochoric_fiber_stretch\":" << material.get_stretch_bar()
      << ",\"normalized_strain_rate\":" << material.get_strain_rate_bar()
      << ",\"full_normalized_strain_rate\":" << material.get_strain_rate()
      << ",\"dPsi_vol_dJ_Pa\":" << material.get_dPsi_vol_dJ()
      << ",\"d2Psi_vol_dJ2_Pa\":" << material.get_d2Psi_vol_dJ2()
      << ",\"active_force_length\":" << material.get_length_stress()
      << ",\"active_force_length_derivative\":" << material.get_dlength_stress_dstretch()
      << ",\"active_force_velocity\":" << material.get_strain_rate_stress()
      << ",\"active_force_velocity_derivative\":" << material.get_dstrain_rate_stress_dstrain_rate()
      << ",\"passive_muscle_stress\":" << material.get_passive_stress()
      << ",\"passive_muscle_stress_derivative\":" << material.get_dpassive_stress_dstretch()
      << ",\"passive_aponeurosis_stress\":" << material.get_aponeurosis_stress()
      << ",\"passive_aponeurosis_stress_derivative\":" << material.get_daponeurosis_stress_dstretch()
      << "}\n";
  }
  return input.eof() ? 0 : 5;
}
